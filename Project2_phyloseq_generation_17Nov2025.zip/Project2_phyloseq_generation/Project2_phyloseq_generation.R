library(tidyverse)
library(dplyr)
library(phyloseq)
library(ape)
library(vegan)
library()

?read_delim

#read in files
otu <- read_delim(file = "feature-table.txt", delim="\t", skip=1)
tax = read_delim(file = "taxonomy.tsv", delim="\t")
meta = read_delim(file = "metadata_final_amb.tsv", delim="\t")
phylotree = read.tree("tree.nwk")

#### Format OTU table ####
# save everything except first column (OTU ID) into a matrix
otu_mat <- as.matrix(otu[,-1])
# Make first column (#OTU ID) the rownames of the new matrix
rownames(otu_mat) <- otu$`#OTU ID`
# Use the "otu_table" function to make an OTU table
OTU <- otu_table(otu_mat, taxa_are_rows = TRUE) 
class(OTU)

#### Format sample metadata ####
# Save everything except sampleid as new data frame
samp_df <- as.data.frame(meta[,-1])
# Make sampleids the rownames
rownames(samp_df)<- meta$'sample-id'
# Make phyloseq sample data with sample_data() function
SAMP <- sample_data(samp_df)
class(SAMP)

#### Formatting taxonomy ####
# Convert taxon strings to a table with separate taxa rank columns
tax_mat <- tax %>% select(-Confidence)%>%
  separate(col=Taxon, sep="; "
           , into = c("Domain","Phylum","Class","Order","Family","Genus","Species")) %>%
  as.matrix() # Saving as a matrix
# Save everything except feature IDs 
tax_mat <- tax_mat[,-1]
# Make sampleids the rownames
rownames(tax_mat) <- tax$`Feature ID`
# Make taxa table
TAX <- tax_table(tax_mat)
class(TAX)

#### Create phyloseq object ####
# Merge all into a phyloseq object
dep_phyloseq <- phyloseq(OTU, SAMP, TAX, phylotree)

######### ANALYZE ##########
# Remove non-bacterial sequences, if any
dep_filt <- subset_taxa(dep_phyloseq,  Domain == "d__Bacteria" & Class!="c__Chloroplast" & Family !="f__Mitochondria")
# Remove ASVs that have less than 5 counts total
dep_filt_nolow <- filter_taxa(dep_filt, function(x) sum(x)>5, prune = TRUE)
# Remove samples with less than 100 reads
dep_final <- prune_samples(sample_sums(dep_filt_nolow)>100, dep_filt_nolow)

# Rarefy samples
# rngseed sets a random number. If you want to reproduce this exact analysis, you need
# to set rngseed the same number each time
# t transposes the table to use rarecurve function
# cex decreases font size
rarecurve(t(as.data.frame(otu_table(dep_final))), cex=0.1)
dep_rare <- rarefy_even_depth(dep_final, rngseed = 1, sample.size = 1000)

##### Saving #####
save(dep_final, file="dep_final.RData")
save(dep_rare, file="dep_rare.RData")
